import React, { useState } from "react";

const initialItems = [
  { id: 1, description: "Shirt", quantity: 5, packed: false },
  { id: 2, description: "Pants", quantity: 2, packed: false },
];

function Logo() {
  return <h1>My Travel List</h1>;
}

function Form({ onAddItem }) {
  const [description, setDescription] = useState(""); 
  const [quantity, setQuantity] = useState(1); 

  const handleSubmit = (e) => {
    e.preventDefault(); 
    if (!description) return; 

    const newItem = {
      id: Date.now(), 
      description, 
      quantity, 
      packed: false, 
    };

    onAddItem(newItem);

    setDescription("");
    setQuantity(1);
  };

  return (
    <form className="add-form" onSubmit={handleSubmit}>
      <h3>What do you need to pack?</h3>
      <input
        type="text"
        placeholder="Item description"
        value={description}
        onChange={(e) => setDescription(e.target.value)} 
      />
        <select 
           type="number"
           min="1"
           value={quantity}
           onChange={(e) => setQuantity(Number(e.target.value))}>
             <option>1</option>
             <option>2</option>
             <option>3</option>
             <option>4</option>
             <option>5</option>
             <option>6</option>
             <option>7</option>
             <option>8</option>
             <option>9</option>
             <option>10</option>
        </select>
      <button type="submit">Add Item</button>
    </form>
  );
}

function PackingList({ items, onDeleteItem, onTogglePacked }) {
  return (
    <div className="list">
      <ul>
        {items.map((item) => (
          <li key={item.id}> 
            <input
              type="checkbox"
              checked={item.packed}
              onChange={() => onTogglePacked(item.id)}
            />
            <span
              style={{
                textDecoration: item.packed ? "line-through" : "none",
              }}
            >
              {item.quantity} x {item.description}
            </span>
            <button onClick={() => onDeleteItem(item.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Stats({ items }) {
  const totalItems = items.length;
  const packedItems = items.filter((item) => item.packed).length;
  const percentage =
    totalItems === 0 ? 0 : Math.round((packedItems / totalItems) * 100);

  return (
    <footer className="stats">
      <em>
        You have {totalItems} items in the list. You already packed {packedItems}{" "}
        ({percentage}%).
      </em>
    </footer>
  );
}

function App() {
  const [items, setItems] = useState([]); 

  const handleAddItem = (newItem) => {
    setItems([...items, newItem]); 
  };

  const handleDeleteItem = (id) => {
    setItems(items.filter((item) => item.id !== id)); 
  };

  const handleTogglePacked = (id) => {
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, packed: !item.packed } : item
      )
    );
  };

  return (
    <div className="app">
      <Logo />
      <Form onAddItem={handleAddItem} />
      <PackingList
        items={items} 
        onDeleteItem={handleDeleteItem}
        onTogglePacked={handleTogglePacked}
      />
      <Stats items={items} />
    </div>
  );
}

export default App;